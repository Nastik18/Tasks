public class ChampionsShip {
    public static void main(String[] args) {
        Champion newChampion = new Champion( "Mersedes", 2017);
        Champion newChampion2 = new Champion( "Mersedes", 2016);
        newChampion.pilot("Lewis Hamilton");
        System.out.println(newChampion.howSeason());
        newChampion.coundry( "Mexican Grand Prix");
        newChampion2.pilot( "Nico Rosberg");
        newChampion2.coundry("Abu Dhabi Grand Prix");
        System.out.println(newChampion2.howSeason());
    }
}
