  class Champion {
    String team;
    int season;

    Champion ( String team, int season){
        this.team = team;
        this.season = season;

        }

    void pilot (String driver){
          System.out.println(driver);
      }
      int howSeason (){
          return season;
      }
      void coundry (String race) {
          System.out.println(race);
      }
  }



